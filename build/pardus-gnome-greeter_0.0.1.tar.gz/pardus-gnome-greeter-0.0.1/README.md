## PARDUS GNOME GREETER
With this application users are able to change the looking of their desktop layout


### Running Application
To test and use application run the following command <br/>
`python3 <project_dir>/pardus-gnome-greeter/src/Main.py`

### Testing Stored Layout
for testing we need to export gsettings schema directory <br>
`export GSETTINGS_SCHEMA_DIR=<project_dir>/pardus-gnome-greeter/schema/`